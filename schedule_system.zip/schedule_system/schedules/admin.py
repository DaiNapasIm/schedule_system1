from django.contrib import admin
from .models import Teacher, Subject, Schedule

admin.site.register(Teacher)
admin.site.register(Subject)
admin.site.register(Schedule)